package com.vatunisia.soh.consultation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsultationApplicationTests {

	@Test
	void contextLoads() {
	}

}
