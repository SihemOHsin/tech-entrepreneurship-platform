package com.vatunisia.soh.expertise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpertiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
